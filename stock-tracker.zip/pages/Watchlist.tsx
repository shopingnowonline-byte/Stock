
import React, { useState } from 'react';
import { WatchlistItem, SheetRow } from '../types';
import { 
  BarChart, Bar, 
  LineChart, Line, 
  AreaChart, Area,
  PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend 
} from 'recharts';

type ChartType = 'bar' | 'line' | 'area' | 'pie' | 'donut';

interface VisualConfig {
  id: string;
  type: ChartType;
  xAxis: string;
  yAxes: string[];
}

interface WatchlistProps {
  items: WatchlistItem[];
  removeItem: (item: WatchlistItem) => void;
  allData: Record<string, SheetRow[]>;
}

const COLORS = ['#4f46e5', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4'];

export const Watchlist: React.FC<WatchlistProps> = ({ items, removeItem, allData }) => {
  const [selectedSymbol, setSelectedSymbol] = useState<string | null>(null);
  
  // Dynamic Chart States
  const [qVisuals, setQVisuals] = useState<VisualConfig[]>([
    { id: 'q-initial', type: 'bar', xAxis: 'Period', yAxes: ['Revenue', 'Profit'] }
  ]);
  const [yVisuals, setYVisuals] = useState<VisualConfig[]>([
    { id: 'y-initial', type: 'line', xAxis: 'Year', yAxes: ['Revenue', 'Profit'] }
  ]);
  
  const priceDaily = allData['PRICE_DAILY'] || [];
  const resultsQuarterly = allData['RESULTS_QUARTERLY'] || [];
  const resultsYearly = allData['RESULTS_YEARLY'] || [];

  const formatPrice = (value: any, compact = false) => {
    if (value === undefined || value === null || String(value).trim() === '') return 'N/A';
    const num = typeof value === 'string' ? parseFloat(value.replace(/[^0-9.-]+/g, "")) : value;
    if (isNaN(num)) return 'N/A';
    
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      notation: compact ? 'compact' : 'standard',
      maximumFractionDigits: 2
    }).format(num);
  };

  const getPriceMetrics = (symbol: string) => {
    if (!priceDaily || priceDaily.length === 0) return null;
    const row = priceDaily.find(r => {
      const symbolKey = Object.keys(r).find(k => k.toLowerCase() === 'symbol' || k.toLowerCase() === 'ticker');
      if (!symbolKey) return false;
      return String(r[symbolKey]).trim().toUpperCase() === symbol.trim().toUpperCase();
    });
    if (!row) return null;
    const getValue = (aliases: string[]) => {
      const key = Object.keys(row).find(k => aliases.some(alias => alias.toLowerCase() === k.trim().toLowerCase()));
      return key ? row[key] : undefined;
    };
    return {
      open: getValue(['open', 'opening', 'op', 'open price']),
      close: getValue(['close', 'closing', 'ltp', 'last price', 'price']),
      high: getValue(['high', 'day high', 'h']),
      low: getValue(['low', 'day low', 'l']),
      high52w: getValue(['52w High', '52 week high', 'yearly high'])
    };
  };

  const addChart = (section: 'q' | 'y', type: ChartType) => {
    const id = `${section}-${Date.now()}`;
    const defaultX = section === 'q' ? 'Period' : 'Year';
    const newConfig: VisualConfig = { id, type, xAxis: defaultX, yAxes: ['Revenue'] };
    if (section === 'q') setQVisuals([...qVisuals, newConfig]);
    else setYVisuals([...yVisuals, newConfig]);
  };

  const removeChart = (section: 'q' | 'y', id: string) => {
    if (section === 'q') setQVisuals(qVisuals.filter(v => v.id !== id));
    else setYVisuals(yVisuals.filter(v => v.id !== id));
  };

  const updateChart = (section: 'q' | 'y', id: string, updates: Partial<VisualConfig>) => {
    const setter = section === 'q' ? setQVisuals : setYVisuals;
    const list = section === 'q' ? qVisuals : yVisuals;
    setter(list.map(v => v.id === id ? { ...v, ...updates } : v));
  };

  if (selectedSymbol) {
    const symbolInfo = items.find(i => i.id === selectedSymbol);
    const qData = resultsQuarterly.filter(r => String(r['Symbol'] || '').toUpperCase() === selectedSymbol.toUpperCase());
    const yData = resultsYearly.filter(r => String(r['Symbol'] || '').toUpperCase() === selectedSymbol.toUpperCase());
    const metrics = getPriceMetrics(selectedSymbol);

    const getAvailableColumns = (data: SheetRow[]) => {
      if (data.length === 0) return [];
      return Object.keys(data[0]).filter(k => k.toLowerCase() !== 'symbol');
    };

    const qColumns = getAvailableColumns(qData);
    const yColumns = getAvailableColumns(yData);

    const prepareChartData = (data: SheetRow[], config: VisualConfig) => {
      return [...data].reverse().map(d => {
        const entry: any = { name: d[config.xAxis] };
        config.yAxes.forEach(key => {
          const val = parseFloat(String(d[key] || '0').replace(/[^0-9.-]+/g, ""));
          entry[key] = isNaN(val) ? 0 : val;
        });
        return entry;
      });
    };

    const renderVisual = (config: VisualConfig, data: SheetRow[], allCols: string[], section: 'q' | 'y') => {
      const chartData = prepareChartData(data, config);
      const isPie = config.type === 'pie' || config.type === 'donut';

      // For pie charts, we use the latest record and map selected Y axes to segments
      // Fix: Use 'any' to ensure dynamic key access doesn't trigger 'unknown' or 'no index signature' errors
      const latestRow: any = data[0] || {};
      const pieData: { name: string; value: number }[] = config.yAxes.map(y => ({
        name: y,
        value: parseFloat(String(latestRow[y] || '0').replace(/[^0-9.-]+/g, ""))
      }));

      return (
        <div key={config.id} className="bg-slate-50/50 rounded-2xl border border-slate-100 p-6 mb-8 group hover:border-indigo-200 transition-all">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
            <div className="flex flex-wrap items-center gap-3">
              <div className="flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-lg border border-slate-200 shadow-sm">
                <span className="text-[10px] font-black text-slate-400 uppercase">Type:</span>
                <select 
                  value={config.type}
                  onChange={(e) => updateChart(section, config.id, { type: e.target.value as ChartType })}
                  className="text-xs font-bold text-slate-700 bg-transparent outline-none cursor-pointer"
                >
                  {['bar', 'line', 'area', 'pie', 'donut'].map(t => <option key={t} value={t}>{t.toUpperCase()}</option>)}
                </select>
              </div>

              <div className="flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-lg border border-slate-200 shadow-sm">
                <span className="text-[10px] font-black text-slate-400 uppercase">X Axis:</span>
                <select 
                  value={config.xAxis}
                  onChange={(e) => updateChart(section, config.id, { xAxis: e.target.value })}
                  className="text-xs font-bold text-slate-700 bg-transparent outline-none cursor-pointer"
                >
                  {allCols.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>

              <div className="flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-lg border border-slate-200 shadow-sm">
                <span className="text-[10px] font-black text-slate-400 uppercase">Y Axis:</span>
                <select 
                  multiple
                  value={config.yAxes}
                  onChange={(e) => {
                    const values = Array.from(e.target.selectedOptions, option => option.value);
                    updateChart(section, config.id, { yAxes: values });
                  }}
                  className="text-[10px] font-bold text-slate-700 bg-transparent outline-none cursor-pointer min-w-[100px]"
                >
                  {allCols.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
                <span className="text-[8px] text-slate-400">(Cmd+Click)</span>
              </div>
            </div>

            <button 
              onClick={() => removeChart(section, config.id)}
              className="p-2 text-slate-300 hover:text-rose-500 transition-colors"
              title="Remove Chart"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
            </button>
          </div>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              {config.type === 'bar' ? (
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis dataKey="name" fontSize={10} axisLine={false} tickLine={false} />
                  <YAxis fontSize={10} axisLine={false} tickLine={false} />
                  <Tooltip cursor={{fill: '#f8fafc'}} />
                  <Legend iconType="circle" wrapperStyle={{fontSize: 10, fontWeight: 700}} />
                  {config.yAxes.map((y, i) => (
                    <Bar key={y} dataKey={y} fill={COLORS[i % COLORS.length]} radius={[4, 4, 0, 0]} />
                  ))}
                </BarChart>
              ) : config.type === 'line' ? (
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis dataKey="name" fontSize={10} axisLine={false} tickLine={false} />
                  <YAxis fontSize={10} axisLine={false} tickLine={false} />
                  <Tooltip />
                  <Legend iconType="circle" wrapperStyle={{fontSize: 10, fontWeight: 700}} />
                  {config.yAxes.map((y, i) => (
                    <Line key={y} type="monotone" dataKey={y} stroke={COLORS[i % COLORS.length]} strokeWidth={3} dot={{r: 4}} />
                  ))}
                </LineChart>
              ) : config.type === 'area' ? (
                <AreaChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis dataKey="name" fontSize={10} axisLine={false} tickLine={false} />
                  <YAxis fontSize={10} axisLine={false} tickLine={false} />
                  <Tooltip />
                  <Legend iconType="circle" wrapperStyle={{fontSize: 10, fontWeight: 700}} />
                  {config.yAxes.map((y, i) => (
                    <Area key={y} type="monotone" dataKey={y} stroke={COLORS[i % COLORS.length]} fill={COLORS[i % COLORS.length]} fillOpacity={0.1} />
                  ))}
                </AreaChart>
              ) : (
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%" cy="50%"
                    innerRadius={config.type === 'donut' ? 60 : 0}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                    // Fix: Use any for label props to prevent property access errors on unknown types
                    label={(props: any) => `${props.name} ${(props.percent * 100).toFixed(0)}%`}
                  >
                    {pieData.map((_, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
                  </Pie>
                  <Tooltip />
                  <Legend verticalAlign="bottom" align="center" />
                </PieChart>
              )}
            </ResponsiveContainer>
          </div>
        </div>
      );
    };

    const latestQ = qData[0] || {};
    const kpis = [
      { label: 'LTP', value: formatPrice(metrics?.close), color: 'text-emerald-600', bg: 'bg-emerald-50' },
      { label: '52w High', value: formatPrice(metrics?.high52w), color: 'text-blue-600', bg: 'bg-blue-50' },
      { label: 'Last Revenue', value: formatPrice(latestQ['Revenue'], true), color: 'text-indigo-600', bg: 'bg-indigo-50' },
      { label: 'Last Profit', value: formatPrice(latestQ['Profit'], true), color: 'text-purple-600', bg: 'bg-purple-50' },
    ];

    return (
      <div className="space-y-8 animate-in fade-in duration-500 pb-20">
        <button onClick={() => setSelectedSymbol(null)} className="flex items-center text-slate-500 hover:text-slate-900 font-bold text-sm transition-colors group">
          <svg className="w-5 h-5 mr-2 group-hover:-translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
          Back to Watchlist
        </button>

        <header className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm flex flex-col md:flex-row justify-between items-center gap-6">
          <div>
            <h2 className="text-5xl font-black text-slate-900 tracking-tighter uppercase">{selectedSymbol}</h2>
            <p className="text-slate-500 font-medium text-lg">{String(symbolInfo?.data['Name'] || 'Company Details')}</p>
          </div>
          <div className="flex flex-col items-end">
             <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Sector</span>
             <span className="px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full text-xs font-bold border border-indigo-100">{String(symbolInfo?.data['Sector'] || 'General')}</span>
          </div>
        </header>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {kpis.map((kpi, idx) => (
            <div key={idx} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4 block">{kpi.label}</span>
              <div className={`text-2xl font-black ${kpi.color}`}>{kpi.value}</div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Quarterly Section */}
          <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-xl font-bold text-slate-800">Quarterly Performance</h3>
              <div className="flex gap-2">
                {['bar', 'line', 'area'].map(type => (
                  <button 
                    key={type} 
                    onClick={() => addChart('q', type as ChartType)}
                    className="w-8 h-8 flex items-center justify-center bg-slate-50 hover:bg-indigo-50 text-slate-400 hover:text-indigo-600 rounded-lg border border-slate-100 transition-all text-[10px] font-bold uppercase"
                  >
                    {type[0]}
                  </button>
                ))}
              </div>
            </div>
            <div className="space-y-4">
              {qVisuals.map(v => renderVisual(v, qData, qColumns, 'q'))}
            </div>
          </div>

          {/* Yearly Section */}
          <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-xl font-bold text-slate-800">Yearly Performance</h3>
              <div className="flex gap-2">
                {['bar', 'line', 'area'].map(type => (
                  <button 
                    key={type} 
                    onClick={() => addChart('y', type as ChartType)}
                    className="w-8 h-8 flex items-center justify-center bg-slate-50 hover:bg-indigo-50 text-slate-400 hover:text-indigo-600 rounded-lg border border-slate-100 transition-all text-[10px] font-bold uppercase"
                  >
                    {type[0]}
                  </button>
                ))}
              </div>
            </div>
            <div className="space-y-4">
              {yVisuals.map(v => renderVisual(v, yData, yColumns, 'y'))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
       <header>
        <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">Active Watchlist</h2>
        <p className="text-slate-500">Monitoring all symbols from <strong className="text-indigo-600">SYMBOLS_MASTER</strong>.</p>
      </header>

      {items.length === 0 ? (
        <div className="bg-white rounded-3xl border-2 border-dashed border-slate-200 p-20 flex flex-col items-center text-center">
          <h3 className="text-lg font-bold text-slate-900">No master symbols found</h3>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {items.map((item, idx) => {
            const metrics = getPriceMetrics(item.id);
            const isPricePositive = metrics && metrics.close !== undefined && metrics.open !== undefined && 
                                   parseFloat(String(metrics.close)) >= parseFloat(String(metrics.open));

            return (
              <div 
                key={`${item.id}-${idx}`} 
                onClick={() => setSelectedSymbol(item.id)}
                className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden hover:shadow-xl hover:border-indigo-300 transition-all group cursor-pointer active:scale-[0.98]"
              >
                <div className="px-6 py-5 border-b border-slate-100 flex justify-between items-start">
                  <div className="flex flex-col">
                    <h4 className="text-3xl font-black text-slate-900 tracking-tighter uppercase group-hover:text-indigo-600 transition-colors">{item.id}</h4>
                    <span className="text-[10px] font-bold text-slate-400 px-2 py-0.5 rounded uppercase tracking-widest w-fit mt-1 border border-slate-100">
                      {String(item.data['Sector'] || 'Market')}
                    </span>
                  </div>
                  <div className="bg-indigo-50 text-indigo-600 p-2 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" /></svg>
                  </div>
                </div>

                <div className="px-6 py-4 bg-slate-50/50 border-b border-slate-100 space-y-3">
                  {!metrics ? (
                    <div className="py-4 text-center">
                      <span className="text-xs font-bold text-slate-400 uppercase tracking-widest italic">Price Data Pending</span>
                      <p className="text-[10px] text-slate-300 mt-1">Check SYMBOL column in PRICE_DAILY</p>
                    </div>
                  ) : (
                    <>
                      <div className="grid grid-cols-2 gap-x-4">
                        <div className="flex flex-col">
                          <span className="text-[9px] uppercase font-black text-slate-400">Open</span>
                          <span className="text-sm font-bold text-slate-600">{formatPrice(metrics.open)}</span>
                        </div>
                        <div className="flex flex-col text-right">
                          <span className="text-[9px] uppercase font-black text-indigo-500">LTP (Close)</span>
                          <span className={`text-sm font-black ${isPricePositive ? 'text-emerald-700' : 'text-rose-700'}`}>
                            {formatPrice(metrics.close)}
                          </span>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-x-4">
                        <div className="flex flex-col">
                          <span className="text-[9px] uppercase font-black text-slate-400">High</span>
                          <span className="text-sm font-bold text-emerald-600">{formatPrice(metrics.high)}</span>
                        </div>
                        <div className="flex flex-col text-right">
                          <span className="text-[9px] uppercase font-black text-slate-400">Low</span>
                          <span className="text-sm font-bold text-rose-600">{formatPrice(metrics.low)}</span>
                        </div>
                      </div>
                      <div className="pt-2 border-t border-slate-100">
                        <div className="flex justify-between items-center bg-blue-50/50 px-2 py-1.5 rounded-lg border border-blue-100/50">
                          <span className="text-[9px] uppercase font-black text-blue-600 tracking-tight">52w High</span>
                          <span className="text-xs font-black text-blue-700">{formatPrice(metrics.high52w)}</span>
                        </div>
                      </div>
                    </>
                  )}
                </div>

                <div className="p-6">
                  <p className="text-sm font-bold text-slate-800 line-clamp-1 mb-2">{String(item.data['Name'] || item.id)}</p>
                  <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-[10px] font-black text-indigo-500 uppercase tracking-widest">Analytics</span>
                    <span className="text-[10px] text-slate-400 font-bold">MCap: {String(item.data['Market Cap'] || 'N/A')}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
