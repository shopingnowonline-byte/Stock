import React from 'react';
import { SheetRow } from '../types';

interface HomeProps {
  data: Record<string, SheetRow[]>;
  isUsingMock: boolean;
  isLoading: boolean;
  error: string | null;
  onRefresh: () => void;
}

export const Home: React.FC<HomeProps> = ({ 
  data, 
  isUsingMock, 
  isLoading, 
  error,
  onRefresh
}) => {
  const sheetNames = Object.keys(data);

  const formatCell = (col: string, val: any) => {
    const value = String(val);
    const isPrice = col.toLowerCase().includes('price') || 
                    ['open', 'close', 'high', 'low', '52w high', 'ltp'].includes(col.toLowerCase());
    
    if (isPrice && !isNaN(parseFloat(value))) {
      const num = parseFloat(value);
      return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        maximumFractionDigits: 2
      }).format(num);
    }
    return value;
  };

  const totalRows = sheetNames.reduce((acc, name) => acc + (data[name]?.length || 0), 0);

  return (
    <div className="space-y-8 pb-20">
      {isUsingMock && (
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex items-center justify-between">
          <div className="flex items-center">
            <div className="p-2 bg-amber-100 text-amber-600 rounded-lg mr-3">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
            </div>
            <div>
              <p className="text-sm font-bold text-amber-900">Viewing Mock Data</p>
              <p className="text-xs text-amber-700">{error || "Connect your Google Sheet in settings to see live data."}</p>
            </div>
          </div>
          <button 
            onClick={onRefresh}
            disabled={isLoading}
            className="text-xs font-bold text-amber-900 bg-amber-200 hover:bg-amber-300 px-3 py-1.5 rounded-lg transition-colors flex items-center"
          >
            {isLoading ? "Connecting..." : "Try Reconnect"}
          </button>
        </div>
      )}

      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">Stock Tracker</h2>
          <p className="text-slate-500">
            Monitoring <strong className="text-blue-600">{sheetNames.length} Sheets</strong> across your DataBase.
          </p>
        </div>
      </header>

      {/* Summary Stats */}
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
        <div className="flex items-center justify-between mb-2">
          <span className="text-slate-500 font-medium">Total Entries</span>
          <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
          </div>
        </div>
        <div className="text-3xl font-bold text-slate-900">{totalRows}</div>
      </div>

      <div className="space-y-10">
        {sheetNames.map(sheetName => {
          const sheetData = data[sheetName] || [];
          const columns = sheetData.length > 0 ? Object.keys(sheetData[0]) : [];
          
          return (
            <section key={sheetName} className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden">
              <div className="p-6 border-b border-slate-100 bg-slate-50/50">
                <h3 className="text-xl font-black text-slate-900 uppercase tracking-tight">{sheetName}</h3>
                <p className="text-xs text-slate-500 font-medium">{sheetData.length} records</p>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="bg-slate-50/30 border-b border-slate-100">
                      {columns.map(col => (
                        <th key={col} className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                          {col}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {sheetData.map((row, idx) => (
                      <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                        {columns.map(col => (
                          <td key={col} className="px-6 py-4 text-sm text-slate-700 font-medium whitespace-nowrap">
                            {formatCell(col, row[col])}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          );
        })}
      </div>
    </div>
  );
};